This is a modification of the pySimReader project to support serial port ("Phoenix type") SIM readers. It uses pyserial and wxpython so make sure that's installed


For more information, please visit http://www.ladyada.net/make/simreader

#####################
Running instructions:

# To start the application, run:
python pySimReader.py


